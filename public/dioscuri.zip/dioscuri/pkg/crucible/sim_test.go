package crucible

import (
	"fmt"
	"strings"
	"testing"
	"time"

	"dioscuri/pkg/cas"
	"dioscuri/pkg/server"
	"dioscuri/pkg/vfs"
)

func TestSimulationLoop(t *testing.T) {
	steps := 1000
	if testing.Short() {
		steps = 100
	}

	memFS := vfs.NewMemoryFS()
	store := cas.NewStore(memFS, "/blobs", "/.staging")
	state := server.NewServerState(memFS, store, "/manifests", "/production.json")
	oracle := NewOracle(memFS, store, "/manifests", "/production.json")

	harness := NewSimHarness(42, time.Date(2026, 1, 1, 0, 0, 0, 0, time.UTC))
	currentSite := GenerateSite(harness.Rand(), 5)
	var history []string

	t.Logf("Running Crucible Simulation with %d steps...", steps)
	start := time.Now()

	for i := 0; i < steps; i++ {
		harness.Advance(time.Minute)
		action := harness.RandomInt(4)

		switch action {
		case 0, 1: // Deploy mutated site
			currentSite = MutateSite(harness.Rand(), currentSite, 1, 2, 1)
			deployID := fmt.Sprintf("dep-%06d", len(history)+1)
			manifestMap := make(map[string]string)

			for path, content := range currentSite {
				hash := cas.HashBytes([]byte(content))
				if err := store.SaveBlob(hash, strings.NewReader(content)); err != nil {
					t.Fatalf("step %d: failed to save blob: %v", i, err)
				}
				manifestMap[path] = hash
			}

			if err := state.CommitDeploy(deployID, manifestMap); err != nil {
				t.Fatalf("step %d: failed to commit deploy: %v", i, err)
			}
			history = append(history, deployID)

		case 2: // Rollback if history has prior deploys
			if len(history) > 1 {
				targetIdx := harness.RandomInt(len(history))
				targetID := history[targetIdx]
				if err := state.Rollback(targetID); err != nil {
					t.Fatalf("step %d: rollback to %s failed: %v", i, targetID, err)
				}
			}

		case 3: // Quarantined Garbage Collection
			if _, err := cas.RunGarbageCollection(memFS, store, "/manifests"); err != nil {
				t.Fatalf("step %d: GC failed: %v", i, err)
			}
		}

		if err := oracle.AssertAll(); err != nil {
			t.Fatalf("step %d: invariant violation: %v", i, err)
		}
	}

	t.Logf("Crucible Simulation completed %d steps in %v with 0 invariant violations.", steps, time.Since(start))
}
