package vfs

import (
	"bytes"
	"io"
	"os"
	"path"
	"sort"
	"strings"
	"sync"
)

// MemoryFS implements a fully thread-safe in-memory virtual filesystem.
type MemoryFS struct {
	mu    sync.RWMutex
	files map[string][]byte
	dirs  map[string]bool
}

func NewMemoryFS() *MemoryFS {
	return &MemoryFS{
		files: make(map[string][]byte),
		dirs:  make(map[string]bool),
	}
}

type memWriter struct {
	buf  bytes.Buffer
	fs   *MemoryFS
	path string
}

func (w *memWriter) Write(p []byte) (int, error) { return w.buf.Write(p) }

func (w *memWriter) Close() error {
	w.fs.mu.Lock()
	defer w.fs.mu.Unlock()
	data := make([]byte, w.buf.Len())
	copy(data, w.buf.Bytes())
	w.fs.files[w.path] = data
	dir := path.Dir(w.path)
	for dir != "/" && dir != "." && dir != "" {
		w.fs.dirs[dir] = true
		dir = path.Dir(dir)
	}
	return nil
}

func (m *MemoryFS) Open(p string) (io.ReadCloser, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	data, ok := m.files[p]
	if !ok {
		return nil, os.ErrNotExist
	}
	cp := make([]byte, len(data))
	copy(cp, data)
	return io.NopCloser(bytes.NewReader(cp)), nil
}

func (m *MemoryFS) Create(p string) (io.WriteCloser, error) {
	return &memWriter{fs: m, path: p}, nil
}

func (m *MemoryFS) Rename(oldPath, newPath string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	data, ok := m.files[oldPath]
	if !ok {
		return os.ErrNotExist
	}
	delete(m.files, oldPath)
	m.files[newPath] = data
	dir := path.Dir(newPath)
	for dir != "/" && dir != "." && dir != "" {
		m.dirs[dir] = true
		dir = path.Dir(dir)
	}
	return nil
}

func (m *MemoryFS) Remove(p string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	delete(m.files, p)
	return nil
}

func (m *MemoryFS) Exists(p string) bool {
	m.mu.RLock()
	defer m.mu.RUnlock()
	_, ok := m.files[p]
	return ok || m.dirs[p]
}

func (m *MemoryFS) MkdirAll(p string) error {
	m.mu.Lock()
	defer m.mu.Unlock()
	dir := p
	for dir != "/" && dir != "." && dir != "" {
		m.dirs[dir] = true
		dir = path.Dir(dir)
	}
	return nil
}

func (m *MemoryFS) ReadDir(dir string) ([]string, error) {
	m.mu.RLock()
	defer m.mu.RUnlock()
	cleanDir := strings.TrimRight(dir, "/")
	prefix := cleanDir + "/"
	seen := make(map[string]bool)
	var list []string
	for p := range m.files {
		if strings.HasPrefix(p, prefix) {
			rel := strings.TrimPrefix(p, prefix)
			parts := strings.Split(rel, "/")
			if len(parts) > 0 && !seen[parts[0]] {
				seen[parts[0]] = true
				list = append(list, parts[0])
			}
		}
	}
	for d := range m.dirs {
		if strings.HasPrefix(d, prefix) {
			rel := strings.TrimPrefix(d, prefix)
			parts := strings.Split(rel, "/")
			if len(parts) > 0 && !seen[parts[0]] {
				seen[parts[0]] = true
				list = append(list, parts[0])
			}
		}
	}
	sort.Strings(list)
	return list, nil
}

func (m *MemoryFS) WalkDir(root string, fn func(p string, isDir bool) error) error {
	m.mu.RLock()
	defer m.mu.RUnlock()
	cleanRoot := strings.TrimRight(root, "/")
	for p := range m.files {
		if strings.HasPrefix(p, cleanRoot) {
			if err := fn(p, false); err != nil {
				return err
			}
		}
	}
	return nil
}
