package manifest

import (
	"strings"
	"testing"
)

func FuzzPathNormalization(f *testing.F) {
	testcases := []string{
		"index.html",
		"/index.html",
		"///style.css",
		"./assets/app.js",
		"blog/../about.html",
	}
	for _, tc := range testcases {
		f.Add(tc)
	}

	f.Fuzz(func(t *testing.T, input string) {
		canonical := CanonicalizePath(input)
		if !strings.HasPrefix(canonical, "/") {
			t.Errorf("CanonicalizePath(%q) = %q; expected leading slash", input, canonical)
		}
		if strings.Contains(canonical, "//") {
			t.Errorf("CanonicalizePath(%q) = %q; contains double slash", input, canonical)
		}
		if strings.Contains(canonical, "/./") || strings.HasSuffix(canonical, "/.") {
			t.Errorf("CanonicalizePath(%q) = %q; contains uncleaned dot", input, canonical)
		}
	})
}
