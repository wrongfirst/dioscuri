module dioscuri

go 1.22
