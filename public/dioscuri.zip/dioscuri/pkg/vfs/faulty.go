package vfs

import (
	"bytes"
	"io"
	"os"
)

// FaultyFS decorates any FS to inject simulated hardware and storage faults.
type FaultyFS struct {
	base       FS
	diskFull   bool
	byteBudget int
}

func NewFaultyFS(base FS) *FaultyFS {
	return &FaultyFS{base: base, byteBudget: -1}
}

func (f *FaultyFS) CrashAfter(bytes int) { f.byteBudget = bytes }
func (f *FaultyFS) SetDiskFull(full bool) { f.diskFull = full }

type faultyWriter struct {
	w  io.WriteCloser
	fs *FaultyFS
}

func (fw *faultyWriter) Write(p []byte) (int, error) {
	if fw.fs.diskFull {
		return 0, ErrDiskFull
	}
	if fw.fs.byteBudget < 0 {
		return fw.w.Write(p)
	}
	if fw.fs.byteBudget == 0 {
		return 0, ErrPowerCut
	}
	if len(p) <= fw.fs.byteBudget {
		n, err := fw.w.Write(p)
		fw.fs.byteBudget -= n
		return n, err
	}
	allowed := p[:fw.fs.byteBudget]
	n, _ := fw.w.Write(allowed)
	fw.fs.byteBudget = 0
	return n, ErrPowerCut
}

func (fw *faultyWriter) Close() error { return fw.w.Close() }

func (f *FaultyFS) Create(p string) (io.WriteCloser, error) {
	if f.diskFull {
		return nil, ErrDiskFull
	}
	if f.byteBudget == 0 {
		return nil, ErrPowerCut
	}
	w, err := f.base.Create(p)
	if err != nil {
		return nil, err
	}
	return &faultyWriter{w: w, fs: f}, nil
}

func (f *FaultyFS) Open(p string) (io.ReadCloser, error) { return f.base.Open(p) }
func (f *FaultyFS) Rename(old, new string) error         { return f.base.Rename(old, new) }
func (f *FaultyFS) Remove(p string) error                { return f.base.Remove(p) }
func (f *FaultyFS) Exists(p string) bool                 { return f.base.Exists(p) }
func (f *FaultyFS) MkdirAll(p string) error              { return f.base.MkdirAll(p) }
func (f *FaultyFS) ReadDir(dir string) ([]string, error) { return f.base.ReadDir(dir) }
func (f *FaultyFS) WalkDir(root string, fn func(string, bool) error) error {
	return f.base.WalkDir(root, fn)
}

func (f *FaultyFS) CorruptByte(path string, offset int) error {
	r, err := f.base.Open(path)
	if err != nil {
		return err
	}
	data, err := io.ReadAll(r)
	r.Close()
	if err != nil {
		return err
	}
	if offset < 0 || offset >= len(data) {
		return os.ErrInvalid
	}
	data[offset] ^= 0xFF
	w, err := f.base.Create(path)
	if err != nil {
		return err
	}
	defer w.Close()
	_, err = io.Copy(w, bytes.NewReader(data))
	return err
}
