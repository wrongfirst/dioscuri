package vfs

import (
	"errors"
	"io"
)

var (
	ErrPowerCut = errors.New("power cut: simulated power loss")
	ErrDiskFull = errors.New("disk full: simulated storage exhaustion")
)

// FS provides an abstract virtual filesystem interface for all Dioscuri storage operations.
type FS interface {
	Open(path string) (io.ReadCloser, error)
	Create(path string) (io.WriteCloser, error)
	Rename(oldPath, newPath string) error
	Remove(path string) error
	Exists(path string) bool
	MkdirAll(path string) error
	ReadDir(path string) ([]string, error)
	WalkDir(root string, fn func(path string, isDir bool) error) error
}
