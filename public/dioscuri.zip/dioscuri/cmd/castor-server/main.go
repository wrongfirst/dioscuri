package main

import (
	"flag"
	"fmt"
	"log"
	"net/http"
	"path/filepath"

	"dioscuri/pkg/cas"
	"dioscuri/pkg/server"
	"dioscuri/pkg/vfs"
)

func main() {
	port := flag.String("port", "8080", "HTTP server port")
	dataDir := flag.String("data", "./data", "Directory for storage and manifests")
	flag.Parse()

	absData, err := filepath.Abs(*dataDir)
	if err != nil {
		log.Fatalf("Invalid data directory: %v", err)
	}

	fs := vfs.NewOSFS(absData)
	store := cas.NewStore(fs, "/blobs", "/.staging")
	state := server.NewServerState(fs, store, "/manifests", "/production.json")
	router := server.NewRouter(state, store)

	addr := ":" + *port
	fmt.Printf("🚀 Castor Server listening on http://localhost%s (data: %s)\n", addr, absData)
	if err := http.ListenAndServe(addr, router); err != nil {
		log.Fatalf("Server error: %v", err)
	}
}
