package crucible

import (
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"path"
	"strings"

	"dioscuri/pkg/cas"
	"dioscuri/pkg/server"
	"dioscuri/pkg/vfs"
)

var (
	ErrCorruptBlobData     = errors.New("blob content digest does not match filename hash")
	ErrProductionBroken    = errors.New("production pointer does not reference an existing manifest")
	ErrDanglingReference   = errors.New("manifest references blob that does not exist in store")
)

type Oracle struct {
	fs          vfs.FS
	store       *cas.Store
	manifestDir string
	pointerPath string
}

func NewOracle(fs vfs.FS, store *cas.Store, manifestDir, pointerPath string) *Oracle {
	return &Oracle{
		fs:          fs,
		store:       store,
		manifestDir: manifestDir,
		pointerPath: pointerPath,
	}
}

func (o *Oracle) AssertBlobIntegrity() error {
	hashes, err := o.store.ListBlobHashes()
	if err != nil {
		return err
	}
	for _, hash := range hashes {
		r, err := o.store.OpenBlob(hash)
		if err != nil {
			return err
		}
		hasher := sha256.New()
		if _, err := io.Copy(hasher, r); err != nil {
			r.Close()
			return err
		}
		r.Close()
		digest := hex.EncodeToString(hasher.Sum(nil))
		if digest != hash {
			return fmt.Errorf("%w: hash=%s actual=%s", ErrCorruptBlobData, hash, digest)
		}
	}
	return nil
}

func (o *Oracle) AssertProductionSafety() error {
	if !o.fs.Exists(o.pointerPath) {
		return nil
	}
	r, err := o.fs.Open(o.pointerPath)
	if err != nil {
		return err
	}
	defer r.Close()

	var ptr server.ActivePointer
	if err := json.NewDecoder(r).Decode(&ptr); err != nil {
		return fmt.Errorf("%w: invalid JSON", ErrProductionBroken)
	}
	if ptr.DeployID == "" {
		return fmt.Errorf("%w: deploy_id is empty", ErrProductionBroken)
	}

	manifestPath := path.Join(o.manifestDir, ptr.DeployID+".json")
	if !o.fs.Exists(manifestPath) {
		return fmt.Errorf("%w: manifest %s not found", ErrProductionBroken, manifestPath)
	}
	return nil
}

func (o *Oracle) AssertNoDanglingReferences() error {
	entries, err := o.fs.ReadDir(o.manifestDir)
	if err != nil {
		return err
	}
	for _, name := range entries {
		if !strings.HasSuffix(name, ".json") {
			continue
		}
		r, err := o.fs.Open(path.Join(o.manifestDir, name))
		if err != nil {
			return err
		}
		var mf map[string]string
		err = json.NewDecoder(r).Decode(&mf)
		r.Close()
		if err != nil {
			return err
		}
		for filePath, blobHash := range mf {
			if !o.store.HasBlob(blobHash) {
				return fmt.Errorf("%w: manifest %s path %s missing blob %s", ErrDanglingReference, name, filePath, blobHash)
			}
		}
	}
	return nil
}

func (o *Oracle) AssertAll() error {
	if err := o.AssertBlobIntegrity(); err != nil {
		return err
	}
	if err := o.AssertProductionSafety(); err != nil {
		return err
	}
	if err := o.AssertNoDanglingReferences(); err != nil {
		return err
	}
	return nil
}
