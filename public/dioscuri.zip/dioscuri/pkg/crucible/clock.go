package crucible

import (
	"math/rand"
	"sync"
	"time"
)

// SimHarness manages simulated virtual time and deterministic random generation.
type SimHarness struct {
	mu  sync.Mutex
	rng *rand.Rand
	now time.Time
}

func NewSimHarness(seed int64, start time.Time) *SimHarness {
	return &SimHarness{
		rng: rand.New(rand.NewSource(seed)),
		now: start,
	}
}

func (h *SimHarness) Now() time.Time {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.now
}

func (h *SimHarness) Advance(d time.Duration) {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.now = h.now.Add(d)
}

func (h *SimHarness) RandomInt(max int) int {
	h.mu.Lock()
	defer h.mu.Unlock()
	return h.rng.Intn(max)
}

func (h *SimHarness) Rand() *rand.Rand {
	return h.rng
}
