package cas

import (
	"crypto/sha256"
	"encoding/hex"
	"errors"
	"io"
	"path"

	"dioscuri/pkg/vfs"
)

var (
	ErrCorruptPayload = errors.New("corrupt payload: content digest does not match claimed hash")
	ErrBlobNotFound   = errors.New("blob not found in content-addressed store")
)

type Store struct {
	fs         vfs.FS
	blobDir    string
	stagingDir string
}

func NewStore(fs vfs.FS, blobDir, stagingDir string) *Store {
	fs.MkdirAll(blobDir)
	fs.MkdirAll(stagingDir)
	return &Store{
		fs:         fs,
		blobDir:    blobDir,
		stagingDir: stagingDir,
	}
}

func (s *Store) BlobPath(hash string) string {
	return path.Join(s.blobDir, hash)
}

func (s *Store) HasBlob(hash string) bool {
	return s.fs.Exists(s.BlobPath(hash))
}

func (s *Store) OpenBlob(hash string) (io.ReadCloser, error) {
	if !s.HasBlob(hash) {
		return nil, ErrBlobNotFound
	}
	return s.fs.Open(s.BlobPath(hash))
}

func (s *Store) SaveBlob(claimedHash string, r io.Reader) error {
	if s.HasBlob(claimedHash) {
		return nil
	}

	stagingPath := path.Join(s.stagingDir, claimedHash+".tmp")
	w, err := s.fs.Create(stagingPath)
	if err != nil {
		return err
	}

	hasher := sha256.New()
	tee := io.TeeReader(r, hasher)
	_, copyErr := io.Copy(w, tee)
	closeErr := w.Close()

	if copyErr != nil {
		s.fs.Remove(stagingPath)
		return copyErr
	}
	if closeErr != nil {
		s.fs.Remove(stagingPath)
		return closeErr
	}

	digest := hex.EncodeToString(hasher.Sum(nil))
	if digest != claimedHash {
		s.fs.Remove(stagingPath)
		return ErrCorruptPayload
	}

	destPath := s.BlobPath(claimedHash)
	if err := s.fs.Rename(stagingPath, destPath); err != nil {
		s.fs.Remove(stagingPath)
		return err
	}

	return nil
}

func (s *Store) ListBlobHashes() ([]string, error) {
	return s.fs.ReadDir(s.blobDir)
}

func (s *Store) DeleteBlob(hash string) error {
	return s.fs.Remove(s.BlobPath(hash))
}
