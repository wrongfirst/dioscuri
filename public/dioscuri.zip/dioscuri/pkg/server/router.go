package server

import (
	"encoding/json"
	"io"
	"net/http"
	"path"

	"dioscuri/pkg/cas"
	"dioscuri/pkg/manifest"
)

type CheckRequest struct {
	Hashes []string `json:"hashes"`
}

type CheckResponse struct {
	Missing []string `json:"missing"`
}

type DeployRequest struct {
	DeployID string            `json:"deploy_id"`
	Manifest map[string]string `json:"manifest"`
}

type RollbackRequest struct {
	DeployID string `json:"deploy_id"`
}

func NewRouter(state *ServerState, store *cas.Store) http.Handler {
	mux := http.NewServeMux()

	// API: Delta check missing blobs
	mux.HandleFunc("POST /api/check", func(w http.ResponseWriter, r *http.Request) {
		var req CheckRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		var missing []string
		for _, h := range req.Hashes {
			if !store.HasBlob(h) {
				missing = append(missing, h)
			}
		}
		if missing == nil {
			missing = []string{}
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(CheckResponse{Missing: missing})
	})

	// API: Upload blob
	mux.HandleFunc("POST /api/blobs/{hash}", func(w http.ResponseWriter, r *http.Request) {
		hash := r.PathValue("hash")
		if hash == "" {
			http.Error(w, "missing hash in route", http.StatusBadRequest)
			return
		}
		if err := store.SaveBlob(hash, r.Body); err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.WriteHeader(http.StatusCreated)
	})

	// API: Deploy manifest & update pointer
	mux.HandleFunc("POST /api/deploy", func(w http.ResponseWriter, r *http.Request) {
		var req DeployRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		if err := state.CommitDeploy(req.DeployID, req.Manifest); err != nil {
			http.Error(w, err.Error(), http.StatusConflict)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode(map[string]string{"status": "active", "deploy_id": req.DeployID})
	})

	// API: Rollback to previous deployment
	mux.HandleFunc("POST /api/rollback", func(w http.ResponseWriter, r *http.Request) {
		var req RollbackRequest
		if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		if err := state.Rollback(req.DeployID); err != nil {
			http.Error(w, err.Error(), http.StatusBadRequest)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		w.WriteHeader(http.StatusOK)
		json.NewEncoder(w).Encode(map[string]string{"status": "active", "deploy_id": req.DeployID})
	})

	// API: Run Garbage Collection
	mux.HandleFunc("POST /api/gc", func(w http.ResponseWriter, r *http.Request) {
		count, err := cas.RunGarbageCollection(state.fs, store, state.manifestDir)
		if err != nil {
			http.Error(w, err.Error(), http.StatusInternalServerError)
			return
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(map[string]int{"deleted": count})
	})

	// Static website serving from active deployment
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		activeID, err := state.GetActiveDeployID()
		if err != nil || activeID == "" {
			http.NotFound(w, r)
			return
		}

		manifestPath := path.Join(state.manifestDir, activeID+".json")
		mr, err := state.fs.Open(manifestPath)
		if err != nil {
			http.NotFound(w, r)
			return
		}
		var mf map[string]string
		json.NewDecoder(mr).Decode(&mf)
		mr.Close()

		reqPath := manifest.CanonicalizePath(r.URL.Path)
		if reqPath == "/" {
			reqPath = "/index.html"
		}

		blobHash, ok := mf[reqPath]
		if !ok {
			http.NotFound(w, r)
			return
		}

		br, err := store.OpenBlob(blobHash)
		if err != nil {
			http.NotFound(w, r)
			return
		}
		defer br.Close()

		switch path.Ext(reqPath) {
		case ".html":
			w.Header().Set("Content-Type", "text/html; charset=utf-8")
		case ".css":
			w.Header().Set("Content-Type", "text/css; charset=utf-8")
		case ".js":
			w.Header().Set("Content-Type", "application/javascript; charset=utf-8")
		}

		io.Copy(w, br)
	})

	return mux
}
