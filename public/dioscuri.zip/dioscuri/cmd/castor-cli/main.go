package main

import (
	"bytes"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"path/filepath"
	"time"

	"dioscuri/pkg/manifest"
	"dioscuri/pkg/vfs"
)

func main() {
	if len(os.Args) < 2 {
		printUsage()
		os.Exit(1)
	}

	serverURL := os.Getenv("CASTOR_URL")
	if serverURL == "" {
		serverURL = "http://localhost:8080"
	}

	cmd := os.Args[1]
	switch cmd {
	case "deploy":
		if len(os.Args) < 3 {
			fmt.Println("Usage: castor-cli deploy <directory>")
			os.Exit(1)
		}
		deployDir(serverURL, os.Args[2])

	case "rollback":
		if len(os.Args) < 3 {
			fmt.Println("Usage: castor-cli rollback <deploy_id>")
			os.Exit(1)
		}
		rollback(serverURL, os.Args[2])

	case "gc":
		runGC(serverURL)

	default:
		printUsage()
		os.Exit(1)
	}
}

func printUsage() {
	fmt.Println("Castor CLI - Static Site Deployment Tool")
	fmt.Println()
	fmt.Println("Commands:")
	fmt.Println("  deploy <dir>       Deploy a static website directory")
	fmt.Println("  rollback <id>      Rollback to a previous deployment ID")
	fmt.Println("  gc                 Run garbage collection on server")
}

func deployDir(serverURL, dir string) {
	absDir, err := filepath.Abs(dir)
	if err != nil {
		fmt.Printf("Error resolving directory %s: %v\n", dir, err)
		os.Exit(1)
	}

	fs := vfs.NewOSFS(absDir)
	mf, err := manifest.BuildManifest(fs, "/")
	if err != nil {
		fmt.Printf("Error scanning directory: %v\n", err)
		os.Exit(1)
	}

	if len(mf) == 0 {
		fmt.Println("Warning: Directory contains no files.")
		return
	}

	fmt.Printf("📦 Scanned %d files. Checking server delta...\n", len(mf))

	// Collect unique hashes
	hashMap := make(map[string]string) // hash -> first matching rel path
	var allHashes []string
	for relPath, hash := range mf {
		if _, seen := hashMap[hash]; !seen {
			hashMap[hash] = relPath
			allHashes = append(allHashes, hash)
		}
	}

	// 1. Delta check
	checkPayload, _ := json.Marshal(map[string][]string{"hashes": allHashes})
	resp, err := http.Post(serverURL+"/api/check", "application/json", bytes.NewReader(checkPayload))
	if err != nil {
		fmt.Printf("Error contacting server at %s: %v\n", serverURL, err)
		os.Exit(1)
	}
	defer resp.Body.Close()

	var checkResp struct {
		Missing []string `json:"missing"`
	}
	json.NewDecoder(resp.Body).Decode(&checkResp)

	// 2. Upload missing blobs
	uploaded := 0
	for _, missingHash := range checkResp.Missing {
		relPath := hashMap[missingHash]
		fileReader, err := fs.Open(relPath)
		if err != nil {
			fmt.Printf("Error opening file %s: %v\n", relPath, err)
			os.Exit(1)
		}
		uploadURL := fmt.Sprintf("%s/api/blobs/%s", serverURL, missingHash)
		uploadResp, err := http.Post(uploadURL, "application/octet-stream", fileReader)
		fileReader.Close()
		if err != nil || uploadResp.StatusCode != http.StatusCreated {
			fmt.Printf("Error uploading blob %s: %v\n", missingHash, err)
			os.Exit(1)
		}
		uploadResp.Body.Close()
		uploaded++
	}

	deduped := len(allHashes) - uploaded
	fmt.Printf("⬆️  Uploaded: %d blobs | ⚡ Deduplicated: %d blobs\n", uploaded, deduped)

	// 3. Commit deployment
	deployID := fmt.Sprintf("dep-%d", time.Now().UnixNano())
	deployPayload, _ := json.Marshal(map[string]interface{}{
		"deploy_id": deployID,
		"manifest":  mf,
	})
	deployResp, err := http.Post(serverURL+"/api/deploy", "application/json", bytes.NewReader(deployPayload))
	if err != nil || deployResp.StatusCode != http.StatusOK {
		fmt.Printf("Error committing deploy: %v\n", err)
		os.Exit(1)
	}
	defer deployResp.Body.Close()

	fmt.Printf("✅ Deployed successfully! Active Deploy ID: %s\n", deployID)
	fmt.Printf("🌐 Visit site at: %s/\n", serverURL)
}

func rollback(serverURL, deployID string) {
	payload, _ := json.Marshal(map[string]string{"deploy_id": deployID})
	resp, err := http.Post(serverURL+"/api/rollback", "application/json", bytes.NewReader(payload))
	if err != nil || resp.StatusCode != http.StatusOK {
		fmt.Printf("Rollback failed: %v\n", err)
		os.Exit(1)
	}
	defer resp.Body.Close()
	fmt.Printf("✅ Rolled back successfully to: %s\n", deployID)
}

func runGC(serverURL string) {
	resp, err := http.Post(serverURL+"/api/gc", "application/json", nil)
	if err != nil || resp.StatusCode != http.StatusOK {
		fmt.Printf("GC failed: %v\n", err)
		os.Exit(1)
	}
	defer resp.Body.Close()
	var res struct {
		Deleted int `json:"deleted"`
	}
	json.NewDecoder(resp.Body).Decode(&res)
	fmt.Printf("🧹 Garbage collection complete. Purged %d unreferenced blobs.\n", res.Deleted)
}
