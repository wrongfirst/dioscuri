package cas

import (
	"encoding/json"
	"path"
	"strings"

	"dioscuri/pkg/vfs"
)

// RunGarbageCollection walks all manifests in manifestDir, marks referenced blobs, and deletes unreferenced blobs.
func RunGarbageCollection(fs vfs.FS, store *Store, manifestDir string) (int, error) {
	manifestFiles, err := fs.ReadDir(manifestDir)
	if err != nil {
		return 0, err
	}

	liveSet := make(map[string]bool)
	for _, mf := range manifestFiles {
		if !strings.HasSuffix(mf, ".json") {
			continue
		}
		r, err := fs.Open(path.Join(manifestDir, mf))
		if err != nil {
			return 0, err
		}
		var manifest map[string]string
		err = json.NewDecoder(r).Decode(&manifest)
		r.Close()
		if err != nil {
			return 0, err
		}
		for _, hash := range manifest {
			liveSet[hash] = true
		}
	}

	storedBlobs, err := store.ListBlobHashes()
	if err != nil {
		return 0, err
	}

	deletedCount := 0
	for _, hash := range storedBlobs {
		if !liveSet[hash] {
			if err := store.DeleteBlob(hash); err != nil {
				return deletedCount, err
			}
			deletedCount++
		}
	}

	return deletedCount, nil
}
