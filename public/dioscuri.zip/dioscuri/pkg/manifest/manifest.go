package manifest

import (
	"encoding/json"
	"io"
	"strings"

	"dioscuri/pkg/cas"
	"dioscuri/pkg/vfs"
)

type Manifest map[string]string

// BuildManifest recursively walks dir in fs, hashes every file, and populates the manifest.
func BuildManifest(fs vfs.FS, dir string) (Manifest, error) {
	manifest := make(Manifest)
	cleanDir := strings.TrimRight(dir, "/")

	err := fs.WalkDir(cleanDir, func(virtualPath string, isDir bool) error {
		if isDir {
			return nil
		}
		r, err := fs.Open(virtualPath)
		if err != nil {
			return err
		}
		hash, err := cas.HashStream(r)
		r.Close()
		if err != nil {
			return err
		}
		rel := strings.TrimPrefix(virtualPath, cleanDir)
		manifest[CanonicalizePath(rel)] = hash
		return nil
	})
	if err != nil {
		return nil, err
	}
	return manifest, nil
}

func SerializeManifest(m Manifest) ([]byte, error) {
	return json.MarshalIndent(m, "", "  ")
}

func DeserializeManifest(r io.Reader) (Manifest, error) {
	var m Manifest
	err := json.NewDecoder(r).Decode(&m)
	return m, err
}
