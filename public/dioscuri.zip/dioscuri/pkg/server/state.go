package server

import (
	"encoding/json"
	"errors"
	"path"
	"sync"

	"dioscuri/pkg/cas"
	"dioscuri/pkg/vfs"
)

var (
	ErrDeployLocked = errors.New("deployment currently in progress")
)

type ActivePointer struct {
	DeployID string `json:"deploy_id"`
}

type ServerState struct {
	fs          vfs.FS
	store       *cas.Store
	manifestDir string
	pointerPath string
	deployMu    sync.Mutex
}

func NewServerState(fs vfs.FS, store *cas.Store, manifestDir, pointerPath string) *ServerState {
	fs.MkdirAll(manifestDir)
	return &ServerState{
		fs:          fs,
		store:       store,
		manifestDir: manifestDir,
		pointerPath: pointerPath,
	}
}

func (s *ServerState) GetActiveDeployID() (string, error) {
	if !s.fs.Exists(s.pointerPath) {
		return "", nil
	}
	r, err := s.fs.Open(s.pointerPath)
	if err != nil {
		return "", err
	}
	defer r.Close()
	var ptr ActivePointer
	if err := json.NewDecoder(r).Decode(&ptr); err != nil {
		return "", err
	}
	return ptr.DeployID, nil
}

func (s *ServerState) UpdatePointer(deployID string) error {
	tmpPath := s.pointerPath + ".tmp"
	w, err := s.fs.Create(tmpPath)
	if err != nil {
		return err
	}
	if err := json.NewEncoder(w).Encode(ActivePointer{DeployID: deployID}); err != nil {
		w.Close()
		s.fs.Remove(tmpPath)
		return err
	}
	if err := w.Close(); err != nil {
		s.fs.Remove(tmpPath)
		return err
	}
	return s.fs.Rename(tmpPath, s.pointerPath)
}

func (s *ServerState) CommitDeploy(deployID string, manifest map[string]string) error {
	if !s.deployMu.TryLock() {
		return ErrDeployLocked
	}
	defer s.deployMu.Unlock()

	// Verify all referenced blobs exist in storage
	for _, hash := range manifest {
		if !s.store.HasBlob(hash) {
			return errors.New("manifest references missing blob: " + hash)
		}
	}

	// Save manifest JSON
	manifestPath := path.Join(s.manifestDir, deployID+".json")
	w, err := s.fs.Create(manifestPath)
	if err != nil {
		return err
	}
	if err := json.NewEncoder(w).Encode(manifest); err != nil {
		w.Close()
		s.fs.Remove(manifestPath)
		return err
	}
	if err := w.Close(); err != nil {
		s.fs.Remove(manifestPath)
		return err
	}

	return s.UpdatePointer(deployID)
}

func (s *ServerState) Rollback(targetDeployID string) error {
	if !s.deployMu.TryLock() {
		return ErrDeployLocked
	}
	defer s.deployMu.Unlock()

	manifestPath := path.Join(s.manifestDir, targetDeployID+".json")
	if !s.fs.Exists(manifestPath) {
		return errors.New("deployment not found: " + targetDeployID)
	}

	return s.UpdatePointer(targetDeployID)
}
