package crucible

import (
	"fmt"
	"math/rand"
	"sort"
)

type Site map[string]string

func GenerateSite(rng *rand.Rand, fileCount int) Site {
	site := make(Site, fileCount)
	for i := 0; i < fileCount; i++ {
		path := fmt.Sprintf("/page_%d.html", i)
		content := fmt.Sprintf("<html><body>Content for page %d (rand: %d)</body></html>", i, rng.Intn(10000))
		site[path] = content
	}
	return site
}

func MutateSite(rng *rand.Rand, base Site, toAdd, toModify, toDelete int) Site {
	result := make(Site, len(base)+toAdd)
	for k, v := range base {
		result[k] = v
	}

	keys := make([]string, 0, len(result))
	for k := range result {
		keys = append(keys, k)
	}
	sort.Strings(keys)

	// Deletions
	for i := 0; i < toDelete && len(keys) > 0; i++ {
		idx := rng.Intn(len(keys))
		deletedKey := keys[idx]
		delete(result, deletedKey)
		keys = append(keys[:idx], keys[idx+1:]...)
	}

	// Modifications
	for i := 0; i < toModify && len(keys) > 0; i++ {
		idx := rng.Intn(len(keys))
		modKey := keys[idx]
		result[modKey] = result[modKey] + fmt.Sprintf("<!-- modified %d -->", rng.Intn(1000))
	}

	// Additions
	for i := 0; i < toAdd; i++ {
		newKey := fmt.Sprintf("/extra_%d_%d.html", len(result), rng.Intn(10000))
		result[newKey] = fmt.Sprintf("<div>Extra page %d</div>", i)
	}

	return result
}
