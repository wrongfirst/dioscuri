package vfs

import (
	"io"
	"io/fs"
	"os"
	"path/filepath"
)

// OSFS implements FS backed by the host operating system's filesystem rooted at a directory.
type OSFS struct {
	root string
}

func NewOSFS(root string) *OSFS {
	abs, err := filepath.Abs(root)
	if err != nil {
		abs = root
	}
	os.MkdirAll(abs, 0755)
	return &OSFS{root: abs}
}

func (o *OSFS) resolve(p string) string {
	clean := filepath.Clean("/" + p)
	return filepath.Join(o.root, filepath.FromSlash(clean))
}

func (o *OSFS) Open(p string) (io.ReadCloser, error) {
	return os.Open(o.resolve(p))
}

func (o *OSFS) Create(p string) (io.WriteCloser, error) {
	resolved := o.resolve(p)
	if err := os.MkdirAll(filepath.Dir(resolved), 0755); err != nil {
		return nil, err
	}
	return os.Create(resolved)
}

func (o *OSFS) Rename(oldPath, newPath string) error {
	resolvedNew := o.resolve(newPath)
	if err := os.MkdirAll(filepath.Dir(resolvedNew), 0755); err != nil {
		return err
	}
	return os.Rename(o.resolve(oldPath), resolvedNew)
}

func (o *OSFS) Remove(p string) error {
	return os.Remove(o.resolve(p))
}

func (o *OSFS) Exists(p string) bool {
	_, err := os.Stat(o.resolve(p))
	return err == nil
}

func (o *OSFS) MkdirAll(p string) error {
	return os.MkdirAll(o.resolve(p), 0755)
}

func (o *OSFS) ReadDir(p string) ([]string, error) {
	entries, err := os.ReadDir(o.resolve(p))
	if err != nil {
		return nil, err
	}
	names := make([]string, len(entries))
	for i, e := range entries {
		names[i] = e.Name()
	}
	return names, nil
}

func (o *OSFS) WalkDir(root string, fn func(p string, isDir bool) error) error {
	target := o.resolve(root)
	if !o.Exists(root) {
		return nil
	}
	return filepath.WalkDir(target, func(filePath string, d fs.DirEntry, err error) error {
		if err != nil {
			return err
		}
		rel, err := filepath.Rel(o.root, filePath)
		if err != nil {
			return err
		}
		virtualPath := "/" + filepath.ToSlash(rel)
		return fn(virtualPath, d.IsDir())
	})
}
