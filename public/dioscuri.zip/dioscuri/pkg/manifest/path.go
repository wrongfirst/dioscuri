package manifest

import (
	"path"
	"strings"
)

// CanonicalizePath strips redundant slashes, resolves dot elements, and guarantees leading slash.
func CanonicalizePath(p string) string {
	cleaned := path.Clean("/" + p)
	if !strings.HasPrefix(cleaned, "/") {
		cleaned = "/" + cleaned
	}
	return cleaned
}
