package cas

import (
	"crypto/sha256"
	"encoding/hex"
	"io"
)

// HashStream computes the SHA-256 hexadecimal digest of any readable stream.
func HashStream(r io.Reader) (string, error) {
	hasher := sha256.New()
	if _, err := io.Copy(hasher, r); err != nil {
		return "", err
	}
	return hex.EncodeToString(hasher.Sum(nil)), nil
}

// HashBytes computes the SHA-256 hexadecimal digest of raw bytes.
func HashBytes(data []byte) string {
	h := sha256.Sum256(data)
	return hex.EncodeToString(h[:])
}
